package com.cg.Mavenlogin.Mavenlogin;

import org.apache.log4j.Logger;

public class HiLogger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Logger log=Logger.getLogger(HiLogger.class);
		
		log.info("hi");

	}

}
