package com.cg.Mavenlogin.Mavenlogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class UserBean {

	@FindBy(how=How.ID,id="name")
	private WebElement name;
	
	@FindBy(how=How.NAME, name="desig")
	private WebElement designation;
	
	@FindBy(how=How.ID,id="country")
	private WebElement country;

	@FindBy(how=How.ID,id="submit")
	private WebElement submit;
	
	@FindBy(how=How.ID,id="reset")
	private WebElement reset;
	
	public String getName() {
		return name.getAttribute("value");
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public String getDesignation() {
		return designation.getAttribute("value");
	}

	public void setDesignation(String designation) {
		this.designation.findElement(By.xpath("/html/body/form/input[@id='"+designation+"']")).click();
	}

	public String getCountry() {
		return country.getAttribute("value");
	}

	public void setCountry(String country) {
		
		this.country.findElement(By.id("country"));
		Select select=new Select(this.country);
		select.selectByValue(country);
	}
	
	public void clickSubmit() {
		submit.click();
	}
	
	public void clickReset() {
		reset.click();
	}
}
