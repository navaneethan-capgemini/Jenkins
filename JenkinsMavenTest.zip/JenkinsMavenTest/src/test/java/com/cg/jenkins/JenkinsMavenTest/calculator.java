package com.cg.jenkins.JenkinsMavenTest;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.TestCase;

public class calculator extends TestCase {

	
	@Given("^I want to write a step with name(\\d+)$")
	public void i_want_to_write_a_step_with_name(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^I check for the (\\d+) in the step$")
	public void i_check_for_the_in_the_step(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^I will verify the success in step$")
	public void i_will_verify_the_success_in_step() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^I will verify the Fail in step$")
	public void i_will_verify_the_Fail_in_step() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

}
