package com.cg.stepdefinition;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.beans.UserBean;
import com.cg.util.DriverUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserStepDefinition {

	private DriverUtil util;
	private WebDriver driver;
	private UserBean bean;
	
	@Before
	public void initialization() {
		util=new DriverUtil();
		driver=util.initiateDriver("chrome");
		bean=new UserBean();
		PageFactory.initElements(driver, bean);
	}
	
	@After
	public void terminate() throws InterruptedException {
		Thread.sleep(3000);
		driver.close();
	}
	
	@Test
	public void testCorrect() throws Throwable {

		i_entered_login_page();
		i_enter_all_credentials_and_I_click_on_submit_button();
		succes_page_appears();
	}

	@Test
	public void testWrong() throws Throwable {
		i_entered_login_page();
		i_click_on_submit_button_without_entering_credentials();
		stays_in_same_page();
	}

	@Given("^I entered login page$")
	public void i_entered_login_page() throws Throwable {
		driver.get("http://localhost:8081/SeleniunPomTask/");
	}

	@When("^I enter all credentials and I click on submit button$")
	public void i_enter_all_credentials_and_I_click_on_submit_button() throws Throwable {
		bean.setName("Ranjith");
		bean.setDesignation("SE");
		bean.setCountry("India");
		bean.clickSubmit();
	}

	@Then("^succes page appears$")
	public void succes_page_appears() throws Throwable {
		String title=driver.getTitle();
		assertEquals("ChildPage", title);
	}

	@When("^I click on submit button without entering credentials$")
	public void i_click_on_submit_button_without_entering_credentials() throws Throwable {
		bean.clickSubmit();
	}

	@Then("^Stays in same page$")
	public void stays_in_same_page() throws Throwable {
		String title=driver.getTitle();
		assertEquals("userDetails", title);
	}
}
