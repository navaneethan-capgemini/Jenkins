package com.cg.jenkins.SeleniumBasics;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HyperLinkTest {
	WebDriver driver;

	@Before
	public void setUp() throws Exception {
		
		System.setProperty("webdriver.chrome.driver","D:\\nav\\BDD\\SeleniumBasics\\Drivers\\chromedriver.exe" );
		driver=new ChromeDriver();
	}

	@After
	public void tearDown() throws Exception {
		driver.close();
	}

	@Test
	public void hyperTest() {
		
		String baseurl="";
		
	}

}
