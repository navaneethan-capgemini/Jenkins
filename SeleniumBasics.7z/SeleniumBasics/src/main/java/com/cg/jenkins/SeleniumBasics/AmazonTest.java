package com.cg.jenkins.SeleniumBasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try
		{
		System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("D:\\nav\\BDD\\SeleniumBasics\\src\\main\\java\\com\\cg\\jenkins\\SeleniumBasics\\login.html");
		WebElement element=driver.findElement(By.name("uname"));
		element.sendKeys("Navaneethan");
		WebElement element1=driver.findElement(By.name("pwd"));
		element1.sendKeys("hello");
		WebElement element2=driver.findElement(By.name("sub"));
		element2.submit();			
		Thread.sleep(10000);		
		System.out.println("page title is: "+driver.getTitle());
		driver.close();
		}catch (Exception e) {
			System.out.println("not found");
		}
		
	}

}
