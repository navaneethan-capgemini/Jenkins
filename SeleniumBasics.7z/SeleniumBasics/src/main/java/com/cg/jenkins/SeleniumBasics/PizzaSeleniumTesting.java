package com.cg.jenkins.SeleniumBasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PizzaSeleniumTesting {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		DriverUtil du=new DriverUtil();
		WebDriver driver1=du.intialize("chrome");
		driver1.manage().window().maximize();
		driver1.get("D:\\nav\\BDD\\SeleniumBasics\\Webcontent\\pizza.html");
		WebElement element=driver1.findElement(By.name("name"));
		element.sendKeys("Navaneethan");
		driver1.findElement(By.id("pizza")).click();						
		driver1.findElement(By.id("Pizza1")).click();
		driver1.findElement(By.id("Pizza2")).click();		
				
		org.openqa.selenium.support.ui.Select sel=new org.openqa.selenium.support.ui.Select(driver1.findElement(By.id("sel")));
		
		sel.selectByValue("Tomato");
		sel.selectByValue("Onion");
		sel.selectByValue("Chicken");
		sel.selectByValue("Panner");
		
		driver1.findElement(By.name("Pizza3")).click();
		driver1.findElement(By.name("Pizza4")).click();
		
		
		driver1.findElement(By.name("instruction")).sendKeys("no instructions");
		
		
		driver1.findElement(By.name("submit")).submit();
		
		Thread.sleep(7000);		
		
		driver1.close();

		
	}
	
}
