package com.cg.jenkins.SeleniumBasics;

import java.sql.Driver;

import org.apache.bcel.generic.Select;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class DriverUtil {
	
	public WebDriver intialize(String driver) throws InterruptedException
	{
		
		if(driver.equals("chrome"))
		{
			System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
			WebDriver driver1=new ChromeDriver();
			return driver1;
		}
			return null;

}
}
